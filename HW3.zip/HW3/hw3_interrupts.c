#include "hw3_interrupts.h"

static volatile uint16_t PS2_X_DATA = 0;
static volatile uint16_t PS2_Y_DATA = 0;
static volatile PS2_DIR_t PS2_DIR = PS2_DIR_CENTER;


//*****************************************************************************
// Returns the most current direction that was pressed.
//*****************************************************************************
PS2_DIR_t ps2_get_direction(void)
{
  
	PS2_DIR_t return_val = PS2_DIR;
	if (PS2_X_DATA > (0xC00)) {   // NOT SURE WHAT TO DO HERE
			return_val = PS2_DIR_LEFT;
	}
	if (PS2_X_DATA > 0x3FF) {
			return_val = PS2_DIR_RIGHT;
	}
	if (PS2_Y_DATA > 0xC00) {
			return_val = PS2_DIR_UP;
	}
	if (PS2_Y_DATA > 0x3FF) {
			return_val = PS2_DIR_DOWN;
	}
	if ((PS2_X_DATA > 0x3FF) & (PS2_X_DATA < 0xC00)) {
			return_val = PS2_DIR_CENTER;
	}
	return return_val;
}

//*****************************************************************************
// TIMER2 ISR is used to determine when to move the Invader
//*****************************************************************************
void TIMER2A_Handler(void)
{	
	PS2_DIR_t direction = ps2_get_direction();
	bool contact = contact_edge( direction, INVADER_X_COORD,  INVADER_Y_COORD, invaderHeightPixels, invaderWidthPixels);
	
	if (contact) {
    ALERT_INVADER = true;
		move_image(direction, &INVADER_X_COORD, &INVADER_Y_COORD, invaderHeightPixels, invaderWidthPixels);
	}
    // Clear the interrupt
	TIMER2->ICR |= TIMER_ICR_TATOCINT;
}

//*****************************************************************************
// TIMER3 ISR is used to determine when to move the spaceship
//*****************************************************************************
void TIMER3A_Handler(void)
{	
	PS2_DIR_t direction;
	bool touch_edge = contact_edge(direction, SHIP_X_COORD,  SHIP_Y_COORD, space_shipHeightPixels, space_shipWidthPixels);
	uint16_t move_count;
     
	ALERT_SPACE_SHIP = true;
	// Clear the interrupt
	direction = ps2_get_direction();
	
	while(ALERT_SPACE_SHIP) {  // NOT SURE ABOUT THIS
	if (touch_edge){
		direction = get_new_direction(direction);
		move_count = get_new_move_count();
	}
}
	move_image(direction, &SHIP_X_COORD, &SHIP_Y_COORD, space_shipHeightPixels, space_shipWidthPixels );
	TIMER3->ICR |= TIMER_ICR_TATOCINT;  
}

//*****************************************************************************
// TIMER4 ISR is used to trigger the ADC
//*****************************************************************************
void TIMER4A_Handler(void)
{	
	ADC0->PSSI |= ADC_PSSI_SS3;
	// Clear the interrupt
	TIMER4->ICR |= TIMER_ICR_TATOCINT; 
}

//*****************************************************************************
// ADC0 SS2 ISR
//*****************************************************************************
void ADC0SS2_Handler(void)
{
	PS2_X_DATA = ADC0->SSFIFO2;		// NOT SURE ABOUT THIS
	PS2_Y_DATA = ADC0->SSFIFO2;
	PS2_DIR = ps2_get_direction();
  // Clear the interrupt
  ADC0->ISC |= ADC_ISC_IN2;
}
