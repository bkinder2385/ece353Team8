// Bitmap info for cactus1
extern const uint8_t cactusBitmaps;
extern const uint8_t cactusWidthPixels;
extern const uint8_t cactusHeightPixels;

