// Bitmap info for pterodactyl
extern const uint8_t pterodactylBitmaps;
extern const uint8_t pterodactylWidthPixels;
extern const uint8_t pterodactylHeightPixels;

