// Bitmap info for trexcrouching
extern const uint8_t trexcrouchingBitmaps;
extern const uint8_t trexcrouchingWidthPixels;
extern const uint8_t trexcrouchingHeightPixels;

