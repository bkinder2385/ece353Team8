// Bitmap info for trexstanding
extern const uint8_t trexstandingBitmaps;
extern const uint8_t trexstandingWidthPixels;
extern const uint8_t trexstandingHeightPixels;

