// Font data for MV Boli 14pt
extern const uint_8 mVBoli_14ptBitmaps[];
extern const FONT_INFO mVBoli_14ptFontInfo;
extern const FONT_CHAR_INFO mVBoli_14ptDescriptors[];

